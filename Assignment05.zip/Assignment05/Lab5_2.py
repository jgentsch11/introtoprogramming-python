
row1 = {"id":"1", 'Name':'Joe', "email":"Joe@gmail.com"}
row2 = {"id":"2", 'Name':'Bob', "email":"Bob@gmail.com"}
row3 = {"id":"3", 'Name':'Steve', "email":"Steve@gmail.com"}
row4 = {"id":"4", 'Name':'Kyle', "email":"Kyle@gmail.com"}
firsttable = [row1,row2,row3,row4]

print(firsttable)
print("\n"*2)
for row in firsttable:
    print(row)

print("\n"*2)

while True:
    intid = input("enter id: ")
    strname = input("enter name: ")
    stremail = input("enter email: ")
    newrow = {"id": intid,"Name": strname,"email": stremail}
    firsttable.append(newrow)
    stranswer = input("Do you want to enter more? y/n ")
    if stranswer.lower() == "n":
        break

strtofile = input("Do you want to save this to a .txt file? y/n ")
if strtofile.lower() == "y":
    objfile = open("mydata.txt", 'w')
    for row in firsttable:
        objfile.write(str(row) + "\n")
    objfile.close()
    print('your data has saved to file')
