
#data
fltsum = 0.0
fltsub = 0.0
fltprod = 0.0
fltquo = 0.0
#fltsub = value1 - value2
#fltprod = value1 * value2
#fltquo = value1 / value2


#processing
#define function
def funfunction(value1, value2):
    decanswer = value1 + value2
    return decanswer

# Presentation

#variable = funfunction(2, 4)
print("The Sum of the values is: " + str(funfunction(3, 3)))
