'''
----------------------------------
Title: Assignment07py
Description: Run a query through python
Change Log: (Who, When, What)
Gentsch, 2/26/2019, Created File
-----------------------------------
'''

#-- Data code --
import psycopg2
import numpy
import pickle

#read in a text file that has database connection details
objFile = open("C:\_python_class\Assignment07\my_fake_credentials", "r")
username_store = objFile.readline().strip()
password_store = objFile.readline().strip()
host_name = objFile.readline().strip()
port = objFile.readline().strip()
objFile.close()

#--processing code--
def getconnection(alias,usern,pw,hostname,port):
    try:
        conn = psycopg2.connect(dbname='databasename', host=hostname,
                           port=port, user=usern, password= pw)
        cur = conn.cursor()
        cur.execute("select *"
                    "from MyTable"
                    "where userid = \'" + alias + "\' ")
        data = numpy.array(cur.fetchall())
        for x in range(len(data)):
            print(data[x], "\t")
        cur.close()
        conn.close()
    except Exception as e:
        print("Connection didn't work. ", e)

#--presentation (I/0) code--
#This passes the alias into the query
alias = input("What is the alias you are looking up? ")
getconnection(alias, username_store, password_store, host_name, port)
input("Press any button to continue")


#pickling data
# Data
dict_Data = {}

# Processing
def dump_pickle():
    # get user Data
    try:
        print("Time to load pickle data")
        str_name = input("What is your name? ")
        while (True):
            try:
                int_zip = int(input("Whats your zip code? "))
            except ValueError as e1:
                print("\nPlease type in a number only for your zip code.")
                continue
            else:
                break
        dict_Data = {"Name": str_name, "ZipCode": int_zip}
        print("\n" + str(dict_Data))
        print(dict_Data["Name"])

        # Initialize Load
        objFile = open("binary_file.dat", "wb")
        pickle.dump(dict_Data, objFile)
        print("load complete")
        objFile.close()

    except Exception as e2:
        print("Hmmm. Something Errored out", e)

def unpickle():
    print("Time to unpickle that pickle!")
    pickle_in = open("binary_file.dat", "rb")
    new_dict = pickle.load(pickle_in)
    print(new_dict)
    pickle_in.close()

#call the load pickle function
dump_pickle()
unpickle()
